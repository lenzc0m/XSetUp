#!/Python27/python.exe


import cgi
import pyodbc
import sys

try:
	sys.path.append("c:\scripts")
	from dbauth import *
except:
	print"Cannot import dbauth.py"
	sys.exit(1)

TRY=0
MAXRETRIES=4

while TRY < MAXRETRIES+100:
	try:
		con = pyodbc.connect('DRIVER={SQL Server};SERVER=%s;DATABASE=NineDragons_Account;UID=%s;PWD=%s' % (DBSERVER,DBUID,DBPWD))
		cur = con.cursor()
		break
	except:
		if TRY==MAXRETRIES:
			print "<result>Failure<resultcode>127";
			sys.exit(0)
	TRY+=1

print "Content-Type: text/html\n"

#print "<result>Success<resultcode>0";

arguments = cgi.FieldStorage()

for i in arguments.keys():
	if i == "userpassword":
		password=arguments[i].value
	if i == "userid":
		userid=arguments[i].value
	if i == "useripaddress":
		useripaddress=arguments[i].value
		
#print "The user %s is trying to login with pass %s" % (userid,password)

#Search the user into the DB table
querystring="select COUNT(userid) as ucount from NineDragons_Account.dbo.Tbl_Member_Password where userid='%s' and userpassword='%s'" % (userid,password)
cur.execute(querystring)
rows = cur.fetchall()
usercount=rows[0].ucount
if usercount != 1:
	print "<result>Failure<resultcode>127";
	
else:
	print "<result>Success<resultcode>0";


cur.close()
sys.exit(0)


print "<br>END SCRIPT<br>"


   